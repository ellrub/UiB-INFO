const footer = document.getElementById("contact")
footer.innerHTML = `<p>Contact Information</p>
                    <p>Phone: <a href="tel:+4712345678">+47 123 45 678</a></p>
                    <p>e-mail: <a href="mailto:user@mail.com">user@mail.com</a></p>
                    <p>Inspired by The Office Michael Scott (Steve Carell) and his business idea ShoeLala, that was never ready for the world</p>
`

