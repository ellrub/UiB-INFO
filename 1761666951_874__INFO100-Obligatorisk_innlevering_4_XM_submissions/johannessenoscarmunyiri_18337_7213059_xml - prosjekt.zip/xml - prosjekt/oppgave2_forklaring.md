#Oppgave 2 - Hvordan XML - dokumentene kan brukes på en nettside

#2a: Brukeren åpner sin profilside.

Når brukeren logger inn og åpner profilen sin, hentes informasjon om personen fra serveren. Serveren sender tilbake XML - dokumentet "person.xml" som inneholder navn og tilhørighet

Dokument: person.xml
Retning: Server --> Klient (Altså fra server til brukerens nettleser) 

EKSEMPEL PÅ DATA SENDT TIL KLIENT VIL VÆRE:

<person id="p001">
    <fulltnavn>Oscar Johannessen</fulltnavn>
    <tilhørighet>Min Nettbutikk AS</tilhørighet>
</person>

#2b: Brukeren sender inn et svar

Brukeren har lest et spørsmål (sporsmal.xml) på nettsiden og vil sende inn et svar. Nettleseren lager et XML - dokument basert på "svar.xml" og sender det til serveren

Dokument: svar.xml
Retning: Klient --> Server (fra brukerens nettleser til serveren) 

eksempel på data sendt fra klient:
<svar id="10">
    <sporsmalRef id="1"/>
    <forfatterRef id="p001"/>
    <tekst>CITIZEN har 5 års bruksgaranti.</tekst>
</svar>