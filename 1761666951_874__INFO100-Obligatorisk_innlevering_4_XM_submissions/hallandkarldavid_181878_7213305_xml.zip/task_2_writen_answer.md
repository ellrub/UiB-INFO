### 2a

When the user logs into the profile page after authentication, the server will send the corresponding XML data (person.xml) to the client to display. It knows what data to send because it can use the author ID associated with the person's data.  
The server stores the user's data so the user can log in from anywhere. But most of the time the user can cache this data to save resources.

### 2b

When the user submits an answer to a question, the answer.xml document is sent from the client to the server. This document contains the answer text, the ID of the question being answered, and the ID of the user submitting the answer. The server receives this document and stores it in the system for future retrieval.