
2. a) A user logs into a web page for problem-solving. We assume that the user has already submitted the (correct) username and password from before. She opens her profile page. Here information about her is presented. (Which XML document is sent to do this? Is the document sent from the client to the server or vice versa?) 

XML-dokumentet fra oppgave 1. b), det som representerer en person og informasjon om denne personen. Her er det serveren som sender dokumentet til brukeren.


2. b) The user has seen a task and wants to submit a solution proposal. What document is transferred in this case? To whom is this document to be sent and from whom?

Her brukes XML-dokumentet fra oppgave 1. c), som representerer et svar/en besvarelse. Her er det brukeren som sender dokumentet til serveren. 